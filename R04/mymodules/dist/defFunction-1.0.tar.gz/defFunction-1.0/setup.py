from setuptools import setup

setup(
    name='defFunction',#nazwa dystrybucji zgodna z nazwa modulu
    version='1.0',
    description='narzedzie do celow cwiczeniowych',
    author='python rusz glowa',
    author_email='mateusz@chujek.com',
    url='headfirstlabs.com',
    py_modules=['defFunction'],#lista plikow w pakiecie
)